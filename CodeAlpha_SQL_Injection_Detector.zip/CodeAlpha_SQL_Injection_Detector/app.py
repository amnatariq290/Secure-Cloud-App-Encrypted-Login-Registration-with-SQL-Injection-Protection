from flask import Flask, render_template, request
from encryption import encrypt_data, decrypt_data
from db import create_table
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecretkey"  # Replace with your own secret key

# Create user table on first run
create_table()

# Database connection
def get_db():
    return sqlite3.connect("users.db")

# -------------------- Registration/Login --------------------

@app.route('/')
def register_form():
    return render_template('index.html')

@app.route('/login_page')
def login_form():
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']

    encrypted_password = encrypt_data(password)

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                   (username, email, encrypted_password))
    conn.commit()
    conn.close()

    return "✅ Registration successful! <a href='/login_page'>Click here to login</a>"

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password_input = request.form['password']

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()

    if result:
        decrypted_password = decrypt_data(result[0])
        if password_input == decrypted_password:
            return render_template("success.html", username=username)

    return "❌ Invalid username or password. <a href='/login_page'>Try Again</a>"

@app.route('/success')
def success():
    return render_template('success.html')

# -------------------- Run the App --------------------
if __name__ == '__main__':
    app.run(debug=True)
