<<<<<<< HEAD
# Secure-Cloud-App-Encrypted-Login-Registration-with-SQL-Injection-Protection
A simple and secure Flask web application that allows users to register and log in using AES-encrypted passwords  with protection against SQL injection attacks.
=======
# CodeAlpha_SQL_Injection_Detector

This is a cloud-enabled secure login system that encrypts user data using AES-256 and prevents SQL injection attacks using prepared statements.

## Features
- AES-256 Encryption for password storage
- Secure login/registration forms
- SQL Injection prevention using safe query practices
- Built with Python, Flask, SQLite

## Run Locally

```bash
pip install -r requirements.txt
python app.py

CodeAlpha_SQL_Injection_Detector/
│
├── app.py              ← Main Flask app
├── encryption.py       ← AES-256 encryption functions
├── db.py               ← Database setup and connection
├── templates/
│   ├── index.html      ← Registration & login page
│   └── success.html    ← Login success message
├── requirements.txt    ← Required libraries
└── README.md           ← GitHub readme
>>>>>>> 1f17ce3 (Initial commit)
